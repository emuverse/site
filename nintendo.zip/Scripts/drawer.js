function openDrawer() {
  document.querySelector(".drawer").style.width = "250px";
}

function closeDrawer() {
  document.querySelector(".drawer").style.width = "0";
}
